﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for EvaluationWindow.xaml
    /// </summary>
    public partial class EvaluationWindow : Window
    {
        private WorkListWindow parent_window;

        private dbDataSet.work_listsDataTable work_lists_data_table;

        private int evaluation;

        private int result_mark;

        public EvaluationWindow(WorkListWindow parent_window, dbDataSet.work_listsDataTable work_lists_data_table)
        {
            InitializeComponent();

            this.work_lists_data_table = work_lists_data_table;
        }

        private void evaluate_work_button_Click(object sender, RoutedEventArgs e)
        {
            GroupBox curr_group_box;
            Grid curr_grid;
            ComboBox curr_combo_box;

            evaluation = 0;

            foreach (UIElement curr_elem_in_main_grid in main_grid.Children)
            {
                curr_group_box = curr_elem_in_main_grid as GroupBox;

                if (curr_group_box != null)
                {
                    curr_grid = curr_group_box.Content as Grid;

                    if (curr_grid != null)
                    {
                        foreach (UIElement curr_elem_in_curr_grid in curr_grid.Children)
                        {
                            curr_combo_box = curr_elem_in_curr_grid as ComboBox;

                            if (curr_combo_box != null)
                            {
                                string[] tmp_strings = curr_combo_box.Text.Split(new string[] { " / " }, StringSplitOptions.RemoveEmptyEntries);

                                evaluation += Convert.ToInt32(tmp_strings[1]);
                            }
                        }
                    }
                }
            }

            if (evaluation >= 0 && evaluation <= 59)
            {
                result_mark = 2;
            }
            else if (evaluation >= 60 && evaluation <= 79)
            {
                result_mark = 3;
            }
            else if (evaluation >= 80 && evaluation <= 109)
            {
                result_mark = 4;
            }
            else if (evaluation >= 110)
            {
                result_mark = 5;
            }

            MessageBox.Show("Оценка - " + result_mark + " / " + evaluation + " баллов");
        }
    }
}
