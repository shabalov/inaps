﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
namespace UMS
{
    /// <summary>
    /// Interaction logic for PortfolioWindow.xaml
    /// </summary>
    public partial class PortfolioWindow : Window
    {
        private OperatingWindow parent_window;

        private DataRow curr_row;

        private void SetComboBox(ComboBox dst, String text)
        {
            for (int i = dst.Items.Count - 1; i > -1; --i)
            {
                dst.SelectedIndex = i;

                if (dst.Text == text)
                {
                    break;
                }
            }
        }

        public PortfolioWindow(OperatingWindow parent_window, bool user_type)
        {
            InitializeComponent();

            if (user_type)
            {
                data_for_printing.IsEnabled = false;

                save_portfolio_button.IsEnabled = false;
            }

            this.parent_window = parent_window;

            curr_row = parent_window.students_rows[parent_window.students_list_view.SelectedIndex];

            student_first_name.Text = curr_row["student_first_name"].ToString();
            student_middle_name.Text = curr_row["student_middle_name"].ToString();
            student_last_name.Text = curr_row["student_last_name"].ToString();
            birthday.Text = curr_row["birthday"].ToString();
            relationship.Text = curr_row["relationship"].ToString();
            citizenship.Text = curr_row["citizenship"].ToString();
            legal_address.Text = curr_row["legal_address"].ToString();

            SetComboBox(education_base, curr_row["education_base"].ToString());

            specialty.Text = curr_row["specialty"].ToString();

            SetComboBox(study_mode, curr_row["study_mode"].ToString());

            group.Text = curr_row["group"].ToString();
            course.Text = curr_row["course"].ToString();
            study_start_date.Text = curr_row["study_start_date"].ToString();
            study_end_date.Text = curr_row["study_end_date"].ToString();

            SetComboBox(academic_degree, curr_row["academic_degree"].ToString());

            document.Text = curr_row["document"].ToString();
            additional_info.Text = curr_row["additional_info"].ToString();
            foreign_language.Text = curr_row["foreign_language"].ToString();

            SetComboBox(language_level, curr_row["language_level"].ToString());
            SetComboBox(computer_level, curr_row["computer_level"].ToString());

            programs.Text = curr_row["programs"].ToString();
            job_place.Text = curr_row["job_place"].ToString();
            scope.Text = curr_row["scope"].ToString();

            SetComboBox(wanna_work_to, curr_row["wanna_work_to"].ToString());

            driver_license.Text = curr_row["driver_license"].ToString();
        }

        private void save_portfolio_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.students_adapter.Update(
                student_first_name.Text,
                student_middle_name.Text,
                student_last_name.Text,
                parent_window.current_group_id,
                birthday.Text,
                relationship.Text,
                citizenship.Text,
                legal_address.Text,
                education_base.Text,
                specialty.Text,
                study_mode.Text,
                group.Text,
                course.Text,
                study_start_date.Text,
                study_end_date.Text,
                academic_degree.Text,
                document.Text,
                additional_info.Text,
                foreign_language.Text,
                language_level.Text,
                computer_level.Text,
                programs.Text,
                job_place.Text,
                scope.Text,
                wanna_work_to.Text,
                driver_license.Text,
                parent_window.current_student_id,
                curr_row["student_first_name"].ToString(),
                curr_row["student_middle_name"].ToString(),
                curr_row["student_last_name"].ToString(),
                parent_window.current_group_id,
                curr_row["birthday"].ToString(),
                curr_row["relationship"].ToString(),
                curr_row["citizenship"].ToString(),
                curr_row["legal_address"].ToString(),
                curr_row["education_base"].ToString(),
                curr_row["specialty"].ToString(),
                curr_row["study_mode"].ToString(),
                curr_row["group"].ToString(),
                curr_row["course"].ToString(),
                curr_row["study_start_date"].ToString(),
                curr_row["study_end_date"].ToString(),
                curr_row["academic_degree"].ToString(),
                curr_row["document"].ToString(),
                curr_row["additional_info"].ToString(),
                curr_row["foreign_language"].ToString(),
                curr_row["language_level"].ToString(),
                curr_row["computer_level"].ToString(),
                curr_row["programs"].ToString(),
                curr_row["job_place"].ToString(),
                curr_row["scope"].ToString(),
                curr_row["wanna_work_to"].ToString(),
                curr_row["driver_license"].ToString());

            this.Close();
        }

        private void print_portfolio_button_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog pd = new PrintDialog();

            if (pd.ShowDialog() == true)
            {
                pd.PrintVisual(data_for_printing, "Портфолио студента");
            }
        }
    }
}
