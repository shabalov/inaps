﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for StatisticsWindow.xaml
    /// </summary>
    public partial class StatisticsWindow : Window
    {
        private int student_id;

        private dbDataSet.work_listsDataTable work_lists_table;
        private dbDataSetTableAdapters.work_listsTableAdapter work_lists_adapter;

        public StatisticsWindow(int student_id)
        {
            InitializeComponent();

            this.student_id = student_id;

            int count_of_semesters = 12;

            work_lists_adapter = new dbDataSetTableAdapters.work_listsTableAdapter();
            work_lists_table = new dbDataSet.work_listsDataTable();

            work_lists_adapter.Fill(work_lists_table);

            for (int i = 0; i < count_of_semesters; ++i)
            {
                DataRow[] selected_rows = work_lists_table.Select("student_id='" + student_id + "' and semester='" + (i + 1) + "'");

                double res_mark = 0;

                for (int j = 0; j < selected_rows.Length; ++j)
                {
                    res_mark += Convert.ToDouble(selected_rows[j]["mark"].ToString());
                }

                res_mark /= selected_rows.Length;

                ((TextBlock)result_marks_grid.Children[i]).Text = res_mark.ToString();

                ((TextBlock)count_of_works_grid.Children[i]).Text = selected_rows.Length.ToString();
            }
        }
    }
}
