﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace UMS
{
    /// <summary>
    /// Interaction logic for DepartmentAdditionWindow.xaml
    /// </summary>
    public partial class DepartmentAdditionWindow : Window
    {
        OperatingWindow parent_window;

        public DepartmentAdditionWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;
        }

        private void add_new_item_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.departments_adapter.Insert(
                new_department_name_text_box.Text,
                Convert.ToInt32(parent_window.faculties_rows[parent_window.faculties_list_view.SelectedIndex]["id"].ToString()));

            this.Close();
        }
    }
}
