﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for StudentAdditionWindow.xaml
    /// </summary>
    public partial class StudentAdditionWindow : Window
    {
        OperatingWindow parent_window;

        public StudentAdditionWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;
        }

        private void add_new_item_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.students_adapter.Insert(
                            new_student_first_name_text_box.Text,
                            new_student_middle_name_text_box.Text,
                            new_student_last_name_text_box.Text,
                            parent_window.current_group_id,
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "");

            this.Close();
        }
    }
}
