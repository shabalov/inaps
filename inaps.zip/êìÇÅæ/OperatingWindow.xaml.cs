﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace UMS
{
    /// <summary>
    /// Interaction logic for OperatingWindow.xaml
    /// </summary>
    public partial class OperatingWindow : Window
    {
        private AuthorizationWindow parent_window;

        private FacultyEditingWindow faculty_editing_window;
        private DepartmentEditingWindow department_editing_window;
        private GroupEditingWindow group_editing_window;
        private StudentEditingWindow student_editing_window;

        private FacultyAdditionWindow faculty_addition_window;
        private DepartmentAdditionWindow department_addition_window;
        private GroupAdditionWindow group_addition_window;
        private StudentAdditionWindow student_addition_window;

        private PortfolioWindow portfolio_window;
        private WorkListWindow work_lsit_window;

        public DataRow[] faculties_rows;
        public DataRow[] departments_rows;
        public DataRow[] groups_rows;
        public DataRow[] students_rows;

        public int current_faculty_id;
        public int current_department_id;
        public int current_group_id;
        public int current_student_id;

        public dbDataSetTableAdapters.facultiesTableAdapter faculties_adapter;
        public dbDataSetTableAdapters.departmentsTableAdapter departments_adapter;
        public dbDataSetTableAdapters.groupsTableAdapter groups_adapter;
        public dbDataSetTableAdapters.studentsTableAdapter students_adapter;

        private bool user_type;


        public OperatingWindow(AuthorizationWindow parent_window, bool user_type)
        {
            InitializeComponent();

            this.parent_window = parent_window;
            this.user_type = user_type;

            faculties_adapter = new dbDataSetTableAdapters.facultiesTableAdapter();
            departments_adapter = new dbDataSetTableAdapters.departmentsTableAdapter();
            groups_adapter = new dbDataSetTableAdapters.groupsTableAdapter();
            students_adapter = new dbDataSetTableAdapters.studentsTableAdapter();

            this.Title = (user_type ? "Преподаватель" : "Студент") + " | Оренбургский Государственный Университет";

            UpdateFaculties();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            parent_window.Show();
        }


        private void update_data_menu_item_Click(object sender, RoutedEventArgs e)
        {
            UpdateFaculties();
        }

        private void UpdateFaculties()
        {
            faculties_list_view.Items.Clear();

            faculties_rows = faculties_adapter.GetData().Select();

            foreach (DataRow curr_row in faculties_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["faculty_name"].ToString();

                faculties_list_view.Items.Add(curr_item);
            }
        }

        private void UpdateDepartments()
        {
            departments_list_view.Items.Clear();

            departments_rows = departments_adapter.GetData().Select("faculty_id='" + current_faculty_id + "'");

            foreach (DataRow curr_row in departments_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["department_name"].ToString();

                departments_list_view.Items.Add(curr_item);
            }
        }

        private void UpdateGroups()
        {
            groups_list_view.Items.Clear();

            groups_rows = groups_adapter.GetData().Select("department_id='" + current_department_id + "'");

            foreach (DataRow curr_row in groups_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["group_name"].ToString();

                groups_list_view.Items.Add(curr_item);
            }
        }

        private void UpdateStudents()
        {
            students_list_view.Items.Clear();

            students_rows = students_adapter.GetData().Select("group_id='" + current_group_id + "'");

            foreach (DataRow curr_row in students_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["student_last_name"].ToString() + " " + curr_row["student_first_name"].ToString() + " " + curr_row["student_middle_name"].ToString();

                students_list_view.Items.Add(curr_item);
            }
        }


        private void faculties_list_view_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (faculties_list_view.SelectedIndex == -1)
            {
                departments_rows = null;

                departments_list_view.Items.Clear();

                return;
            }

            current_faculty_id = Convert.ToInt32(faculties_rows[faculties_list_view.SelectedIndex]["id"]);

            UpdateDepartments();
        }

        private void departments_list_view_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (departments_list_view.SelectedIndex == -1)
            {
                groups_rows = null;

                groups_list_view.Items.Clear();

                return;
            }

            current_department_id = Convert.ToInt32(departments_rows[departments_list_view.SelectedIndex]["id"]);

            UpdateGroups();
        }


        private void groups_list_view_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (groups_list_view.SelectedIndex == -1)
            {
                students_rows = null;

                students_list_view.Items.Clear();

                return;
            }

            current_group_id = Convert.ToInt32(groups_rows[groups_list_view.SelectedIndex]["id"]);

            UpdateStudents();
        }


        private void students_list_view_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            current_student_id = Convert.ToInt32(students_rows[students_list_view.SelectedIndex]["id"]);
        }


        private void remove_faculty_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (faculties_list_view.SelectedIndex == -1)
            {
                return;
            }

            string faculty_name = faculties_rows[faculties_list_view.SelectedIndex]["faculty_name"].ToString();

            faculties_adapter.Delete(current_faculty_id, faculty_name);

            UpdateFaculties();
        }

        private void remove_department_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (departments_list_view.SelectedIndex == -1)
            {
                return;
            }

            string department_name = departments_rows[departments_list_view.SelectedIndex]["department_name"].ToString();

            departments_adapter.Delete(current_department_id, department_name, current_faculty_id);

            UpdateDepartments();
        }

        private void remove_group_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (groups_list_view.SelectedIndex == -1)
            {
                return;
            }

            string group_name = groups_rows[groups_list_view.SelectedIndex]["group_name"].ToString();

            groups_adapter.Delete(current_group_id, group_name, current_department_id);

            UpdateGroups();
        }

        private void remove_student_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            DataRow curr_student_row = students_rows[students_list_view.SelectedIndex];

            students_adapter.Delete(
                current_student_id,
                curr_student_row["student_first_name"].ToString() + " ",
                curr_student_row["student_middle_name"].ToString(),
                curr_student_row["student_last_name"].ToString(),
                current_group_id,
                curr_student_row["birthday"].ToString(),
                curr_student_row["relationship"].ToString(),
                curr_student_row["citizenship"].ToString(),
                curr_student_row["legal_address"].ToString(),
                curr_student_row["education_base"].ToString(),
                curr_student_row["specialty"].ToString(),
                curr_student_row["study_mode"].ToString(),
                curr_student_row["group"].ToString(),
                curr_student_row["course"].ToString(),
                curr_student_row["study_start_date"].ToString(),
                curr_student_row["study_end_date"].ToString(),
                curr_student_row["academic_degree"].ToString(),
                curr_student_row["document"].ToString(),
                curr_student_row["additional_info"].ToString(),
                curr_student_row["foreign_language"].ToString(),
                curr_student_row["language_level"].ToString(),
                curr_student_row["computer_level"].ToString(),
                curr_student_row["programs"].ToString(),
                curr_student_row["job_place"].ToString(),
                curr_student_row["scope"].ToString(),
                curr_student_row["wanna_work_to"].ToString(),
                curr_student_row["driver_license"].ToString());

            UpdateStudents();
        }

        private void common_event_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            if (!user_type)
            {
                e.Handled = true;
            }
        }

        private void edit_faculty_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (faculties_list_view.SelectedIndex == -1)
            {
                return;
            }

            faculty_editing_window = new FacultyEditingWindow(this);

            faculty_editing_window.Owner = this;

            faculty_editing_window.ShowDialog();

            UpdateFaculties();
        }

        private void edit_department_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (departments_list_view.SelectedIndex == -1)
            {
                return;
            }

            department_editing_window = new DepartmentEditingWindow(this);

            department_editing_window.ShowDialog();

            UpdateDepartments();
        }


        private void edit_group_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (groups_list_view.SelectedIndex == -1)
            {
                return;
            }

            group_editing_window = new GroupEditingWindow(this);

            group_editing_window.ShowDialog();

            UpdateGroups();
        }

        private void edit_student_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            student_editing_window = new StudentEditingWindow(this);

            student_editing_window.ShowDialog();

            UpdateStudents();
        }

        private void add_faculty_menu_item_Click(object sender, RoutedEventArgs e)
        {
            faculty_addition_window = new FacultyAdditionWindow(this);

            faculty_addition_window.ShowDialog();

            UpdateFaculties();
        }

        private void add_department_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (faculties_list_view.SelectedIndex == -1)
            {
                return;
            }

            department_addition_window = new DepartmentAdditionWindow(this);

            department_addition_window.ShowDialog();

            UpdateDepartments();
        }

        private void add_group_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (departments_list_view.SelectedIndex == -1)
            {
                return;
            }

            group_addition_window = new GroupAdditionWindow(this);

            group_addition_window.ShowDialog();

            UpdateGroups();
        }

        private void add_student_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (groups_list_view.SelectedIndex == -1)
            {
                return;
            }

            student_addition_window = new StudentAdditionWindow(this);

            student_addition_window.ShowDialog();

            UpdateStudents();
        }

        private void open_portfolio_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            portfolio_window = new PortfolioWindow(this, user_type);

            portfolio_window.ShowDialog();

            UpdateStudents();
        }

        private void open_work_list_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            work_lsit_window = new WorkListWindow(this, user_type);

            work_lsit_window.ShowDialog();
        }

        private void open_statistics_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (students_list_view.SelectedIndex == -1)
            {
                return;
            }

            StatisticsWindow statistics_window = new StatisticsWindow(current_student_id);

            statistics_window.ShowDialog();
        }
    }
}
