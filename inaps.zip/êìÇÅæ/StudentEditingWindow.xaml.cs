﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace UMS
{
    /// <summary>
    /// Interaction logic for StudentEditingWindow.xaml
    /// </summary>
    public partial class StudentEditingWindow : Window
    {
        private OperatingWindow parent_window;

        DataRow curr_student_row;

        public StudentEditingWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;

            curr_student_row = parent_window.students_rows[parent_window.students_list_view.SelectedIndex];

            current_student_first_name_text_box.Text = curr_student_row["student_first_name"].ToString();
            current_student_middle_name_text_box.Text = curr_student_row["student_middle_name"].ToString();
            current_student_last_name_text_box.Text = curr_student_row["student_last_name"].ToString();

            current_group_name_text_box.Text = parent_window.groups_rows[parent_window.groups_list_view.SelectedIndex]["group_name"].ToString();

            new_groups_combo_box.Items.Clear();

            foreach (DataRow curr_row in parent_window.groups_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["group_name"].ToString();

                new_groups_combo_box.Items.Add(curr_item);
            }

            new_groups_combo_box.SelectedIndex = parent_window.groups_list_view.SelectedIndex;
        }

        private void apply_changes_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.students_adapter.Update(
                new_student_first_name_text_box.Text,
                new_student_middle_name_text_box.Text,
                new_student_last_name_text_box.Text,
                Convert.ToInt32(parent_window.groups_rows[new_groups_combo_box.SelectedIndex]["id"]),
                curr_student_row["birthday"].ToString(),
                curr_student_row["relationship"].ToString(),
                curr_student_row["citizenship"].ToString(),
                curr_student_row["legal_address"].ToString(),
                curr_student_row["education_base"].ToString(),
                curr_student_row["specialty"].ToString(),
                curr_student_row["study_mode"].ToString(),
                curr_student_row["group"].ToString(),
                curr_student_row["course"].ToString(),
                curr_student_row["study_start_date"].ToString(),
                curr_student_row["study_end_date"].ToString(),
                curr_student_row["academic_degree"].ToString(),
                curr_student_row["document"].ToString(),
                curr_student_row["additional_info"].ToString(),
                curr_student_row["foreign_language"].ToString(),
                curr_student_row["language_level"].ToString(),
                curr_student_row["computer_level"].ToString(),
                curr_student_row["programs"].ToString(),
                curr_student_row["job_place"].ToString(),
                curr_student_row["scope"].ToString(),
                curr_student_row["wanna_work_to"].ToString(),
                curr_student_row["driver_license"].ToString(),
                parent_window.current_student_id,
                current_student_first_name_text_box.Text,
                current_student_middle_name_text_box.Text,
                current_student_last_name_text_box.Text,
                parent_window.current_group_id,
                curr_student_row["birthday"].ToString(),
                curr_student_row["relationship"].ToString(),
                curr_student_row["citizenship"].ToString(),
                curr_student_row["legal_address"].ToString(),
                curr_student_row["education_base"].ToString(),
                curr_student_row["specialty"].ToString(),
                curr_student_row["study_mode"].ToString(),
                curr_student_row["group"].ToString(),
                curr_student_row["course"].ToString(),
                curr_student_row["study_start_date"].ToString(),
                curr_student_row["study_end_date"].ToString(),
                curr_student_row["academic_degree"].ToString(),
                curr_student_row["document"].ToString(),
                curr_student_row["additional_info"].ToString(),
                curr_student_row["foreign_language"].ToString(),
                curr_student_row["language_level"].ToString(),
                curr_student_row["computer_level"].ToString(),
                curr_student_row["programs"].ToString(),
                curr_student_row["job_place"].ToString(),
                curr_student_row["scope"].ToString(),
                curr_student_row["wanna_work_to"].ToString(),
                curr_student_row["driver_license"].ToString());

            this.Close();
        }
    }
}
