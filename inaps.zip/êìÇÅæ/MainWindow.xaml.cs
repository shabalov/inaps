﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public AuthorizationWindow authorization_window;


        public MainWindow()
        {
            InitializeComponent();
        }

        private void exit_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void authorization_button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            if (authorization_window == null)
            {
                authorization_window = new AuthorizationWindow(this);
            }

            authorization_window.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            try
            {
                authorization_window.Close();
            }
            catch (Exception error)
            {

            }
        }

        private void operation_modes_button_Click(object sender, RoutedEventArgs e)
        {
            WorkModesWindow window = new WorkModesWindow();

            window.ShowDialog();
        }

        private void guide_button_Click(object sender, RoutedEventArgs e)
        {
            WorkGuideWindow window = new WorkGuideWindow();

            window.ShowDialog();
        }

        private void about_button_Click(object sender, RoutedEventArgs e)
        {
            AboutProjectWindow window = new AboutProjectWindow();

            window.ShowDialog();
        }

        private void developers_button_Click(object sender, RoutedEventArgs e)
        {
            DeveloperInfoWindow window = new DeveloperInfoWindow();

            window.ShowDialog();
        }
    }
}
