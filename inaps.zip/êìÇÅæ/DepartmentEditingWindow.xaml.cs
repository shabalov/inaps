﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace UMS
{
    /// <summary>
    /// Interaction logic for DepartmentEditingWindow.xaml
    /// </summary>
    public partial class DepartmentEditingWindow : Window
    {
        private OperatingWindow parent_window;

        public DepartmentEditingWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;

            current_department_name_text_box.Text = parent_window.departments_adapter.GetData().Select("id='" + parent_window.current_department_id + "'")[0]["department_name"].ToString();
            current_faculty_name_text_box.Text = parent_window.faculties_rows[parent_window.faculties_list_view.SelectedIndex]["faculty_name"].ToString();

            new_faculties_combo_box.Items.Clear();

            foreach (DataRow curr_row in parent_window.faculties_rows)
            {
                ListViewItem curr_item = new ListViewItem();

                curr_item.Content = curr_row["faculty_name"].ToString();

                new_faculties_combo_box.Items.Add(curr_item);
            }

            new_faculties_combo_box.SelectedIndex = parent_window.faculties_list_view.SelectedIndex;
        }

        private void apply_changes_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.departments_adapter.Update(
                new_department_name_text_box.Text, 
                Convert.ToInt32(parent_window.faculties_rows[new_faculties_combo_box.SelectedIndex]["id"]), 
                parent_window.current_department_id, current_department_name_text_box.Text, 
                Convert.ToInt32(parent_window.faculties_rows[parent_window.faculties_list_view.SelectedIndex]["id"]));

            this.Close();
        }
    }
}
