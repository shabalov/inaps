﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Diagnostics;

namespace UMS
{
    /// <summary>
    /// Interaction logic for WorkListWindow.xaml
    /// </summary>
    /// 
    public class WorkList : INotifyPropertyChanged
    {
        private string subject;
        private string lecturer;
        private string deadline;
        private string name;
        private string mark;
        private string selfmark;
        private string note;

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public WorkList(string subject, string lecturer)
        {
            this.subject = subject;
            this.lecturer = lecturer;
        }

        public string Subject
        {
            get
            {
                return subject;
            }
            set
            {
                subject = value;

                this.OnPropertyChanged("Subject");
            }
        }

        public string Lecturer
        {
            get
            {
                return lecturer;
            }
            set
            {
                lecturer = value;

                this.OnPropertyChanged("Lecturer");
            }
        }

        public string Deadline
        {
            get
            {
                return deadline;
            }
            set
            {
                deadline = value;

                this.OnPropertyChanged("Deadline");
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;

                this.OnPropertyChanged("Name");
            }
        }

        public string Mark
        {
            get
            {
                return mark;
            }
            set
            {
                mark = value;

                this.OnPropertyChanged("Mark");
            }
        }

        public string Selfmark
        {
            get
            {
                return selfmark;
            }
            set
            {
                selfmark = value;

                this.OnPropertyChanged("Selfmark");
            }
        }

        public string Note
        {
            get
            {
                return note;
            }
            set
            {
                note = value;

                this.OnPropertyChanged("Note");
            }
        }

        public WorkList()
        {

        }
    }

    public partial class WorkListWindow : Window
    {
        private OperatingWindow parent_window;

        private DataRow curr_student_row;

        private dbDataSet.work_listsDataTable work_lists_data_table;

        private dbDataSetTableAdapters.work_listsTableAdapter work_lists_adapter;

        public WorkListWindow(OperatingWindow parent_window, bool user_type)
        {
            InitializeComponent();

            this.parent_window = parent_window;

            curr_student_row = parent_window.students_rows[parent_window.students_list_view.SelectedIndex];


            work_lists_adapter = new dbDataSetTableAdapters.work_listsTableAdapter();


            work_lists_data_table = new dbDataSet.work_listsDataTable();

            work_lists_data_table.DefaultView.RowFilter = "student_id='" + parent_window.current_student_id + "'";

            work_lists_adapter.Fill(work_lists_data_table);

            work_list_data_grid.ItemsSource = work_lists_data_table.DefaultView;


            this.Title = "Список работ | " + curr_student_row["student_last_name"].ToString() + " " +
                curr_student_row["student_first_name"].ToString() + " " +
                curr_student_row["student_middle_name"].ToString();

            if (user_type)
            {
                work_list_data_grid.Columns[7].IsReadOnly = true;
                work_list_data_grid.Columns[5].IsReadOnly = true;
            }
            else
            {
                for (int i = 0; i < work_list_data_grid.Columns.Count; ++i)
                {
                    work_list_data_grid.Columns[i].IsReadOnly = true;
                }

                work_list_data_grid.Columns[7].IsReadOnly = false;
                work_list_data_grid.Columns[5].IsReadOnly = false;
            }
        }


        private void HyperlinkClickHandler(object sender, RoutedEventArgs e)
        {
            Hyperlink link = (Hyperlink)e.OriginalSource;
            Process.Start(link.NavigateUri.AbsoluteUri);
        }


        private void add_work_menu_item_Click(object sender, RoutedEventArgs e)
        {
            DataRow new_row = work_lists_data_table.NewRow();

            new_row["student_id"] = parent_window.current_student_id;

            work_lists_data_table.Addwork_listsRow((dbDataSet.work_listsRow)new_row);
        }

        private void remove_work_menu_item_Click(object sender, RoutedEventArgs e)
        {
            if (work_list_data_grid.SelectedIndex == -1)
            {
                return;
            }

            work_lists_data_table.Rows[work_list_data_grid.SelectedIndex].Delete();
        }

        private void save_works_menu_item_Click(object sender, RoutedEventArgs e)
        {
            work_lists_adapter.Update(work_lists_data_table);

            work_lists_adapter.Fill(work_lists_data_table);
        }

        private void semester_combo_box_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (semester_combo_box.SelectedIndex == 0)
                {
                    work_lists_data_table.DefaultView.RowFilter = "student_id='" + parent_window.current_student_id + "'";
                }
                else
                {
                    work_lists_data_table.DefaultView.RowFilter = "student_id='" + parent_window.current_student_id + "' and " +
                        "semester='" + semester_combo_box.SelectedIndex + "'";
                }
            }
            catch
            {

            }
        }

        private void open_evaluation_window_Click(object sender, RoutedEventArgs e)
        {
           EvaluationWindow evaluation_window = new EvaluationWindow(this, work_lists_data_table);

            evaluation_window.ShowDialog();
        }

        private void work_list_data_grid_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            if (work_list_data_grid.SelectedIndex == -1)
            {
                open_evaluation_window.IsEnabled = false;
            }
            else
            {
                open_evaluation_window.IsEnabled = true;
            }
        }
    }
}
