﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace UMS
{
    /// <summary>
    /// Interaction logic for Authorization.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        private MainWindow parent_window;

        private OperatingWindow operating_window;

        public AuthorizationWindow(MainWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;
        }

        private void go_back_button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();

            parent_window.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            try
            {
                parent_window.authorization_window = null;

                parent_window.Show();
            }
            catch (Exception error)
            {

            }
        }

        private void lecturer_authorization_button_Click(object sender, RoutedEventArgs e)
        {
            DataRow[] lecturers_accounts_rows = (new dbDataSetTableAdapters.lecturers_accountsTableAdapter()).GetData().Select(
                "lecturer_login='" + login_text_box.Text + "' AND " +
                "lecturer_password='" + password_text_box.Password + "'");
            
            if (lecturers_accounts_rows.Length == 1)
            {
                this.Hide();

                operating_window = new OperatingWindow(this, false);

                operating_window.Show();
            }
            else
            {
                MessageBox.Show("Неверный логин и / или пароль", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }

        private void admin_authorization_button_Click(object sender, RoutedEventArgs e)
        {
            DataRow[] admins_accounts_rows = (new dbDataSetTableAdapters.admins_accountsTableAdapter()).GetData().Select(
                "admin_login='" + login_text_box.Text + "' AND " +
                "admin_password='" + password_text_box.Password + "'");

            if (admins_accounts_rows.Length == 1)
            {
                this.Hide();

                operating_window = new OperatingWindow(this, true);

                operating_window.Show();
            }
            else
            {
                MessageBox.Show("Неверный логин и / или пароль", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }
    }
}
