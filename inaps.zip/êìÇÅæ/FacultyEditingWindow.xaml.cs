﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for FacultyEditingWindow.xaml
    /// </summary>
    public partial class FacultyEditingWindow : Window
    {
        private OperatingWindow parent_window;

        public FacultyEditingWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;

            current_faculty_name_text_box.Text = parent_window.faculties_adapter.GetData().Select("id='" + parent_window.current_faculty_id + "'")[0]["faculty_name"].ToString();
        }

        private void apply_changes_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.faculties_adapter.Update(new_faculty_name_text_box.Text, parent_window.current_faculty_id, current_faculty_name_text_box.Text);

            this.Close();
        }
    }
}
