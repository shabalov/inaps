﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UMS
{
    /// <summary>
    /// Interaction logic for FacultyAdditionWindow.xaml
    /// </summary>
    public partial class FacultyAdditionWindow : Window
    {
        OperatingWindow parent_window;

        public FacultyAdditionWindow(OperatingWindow parent_window)
        {
            InitializeComponent();

            this.parent_window = parent_window;
        }

        private void add_new_item_button_Click(object sender, RoutedEventArgs e)
        {
            parent_window.faculties_adapter.Insert(new_faculty_name_text_box.Text);

            this.Close();
        }
    }
}
